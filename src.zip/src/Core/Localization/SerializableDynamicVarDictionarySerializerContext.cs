using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

namespace MegaCrit.Sts2.Core.Localization;

[JsonSourceGenerationOptions(WriteIndented = true, IncludeFields = true, UseStringEnumConverter = true)]
[JsonSerializable(typeof(Dictionary<string, SerializableDynamicVar>))]
[GeneratedCode("System.Text.Json.SourceGeneration", "9.0.12.31616")]
internal class SerializableDynamicVarDictionarySerializerContext : JsonSerializerContext, IJsonTypeInfoResolver
{
	private JsonTypeInfo<bool>? _Boolean;

	private JsonTypeInfo<decimal>? _Decimal;

	private JsonTypeInfo<DynamicVarType>? _DynamicVarType;

	private JsonTypeInfo<SerializableDynamicVar>? _SerializableDynamicVar;

	private JsonTypeInfo<Dictionary<string, SerializableDynamicVar>>? _DictionaryStringSerializableDynamicVar;

	private JsonTypeInfo<string>? _String;

	private static readonly JsonSerializerOptions s_defaultOptions = new JsonSerializerOptions
	{
		IncludeFields = true,
		WriteIndented = true
	};

	private const BindingFlags InstanceMemberBindingFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

	private static readonly JsonEncodedText PropName_type = JsonEncodedText.Encode("type");

	private static readonly JsonEncodedText PropName_decimal_value = JsonEncodedText.Encode("decimal_value");

	private static readonly JsonEncodedText PropName_bool_value = JsonEncodedText.Encode("bool_value");

	private static readonly JsonEncodedText PropName_string_value = JsonEncodedText.Encode("string_value");

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<bool> Boolean => _Boolean ?? (_Boolean = (JsonTypeInfo<bool>)base.Options.GetTypeInfo(typeof(bool)));

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<decimal> Decimal => _Decimal ?? (_Decimal = (JsonTypeInfo<decimal>)base.Options.GetTypeInfo(typeof(decimal)));

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<DynamicVarType> DynamicVarType => _DynamicVarType ?? (_DynamicVarType = (JsonTypeInfo<DynamicVarType>)base.Options.GetTypeInfo(typeof(DynamicVarType)));

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<SerializableDynamicVar> SerializableDynamicVar => _SerializableDynamicVar ?? (_SerializableDynamicVar = (JsonTypeInfo<SerializableDynamicVar>)base.Options.GetTypeInfo(typeof(SerializableDynamicVar)));

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<Dictionary<string, SerializableDynamicVar>> DictionaryStringSerializableDynamicVar => _DictionaryStringSerializableDynamicVar ?? (_DictionaryStringSerializableDynamicVar = (JsonTypeInfo<Dictionary<string, SerializableDynamicVar>>)base.Options.GetTypeInfo(typeof(Dictionary<string, SerializableDynamicVar>)));

	/// <summary>
	/// Defines the source generated JSON serialization contract metadata for a given type.
	/// </summary>
	public JsonTypeInfo<string> String => _String ?? (_String = (JsonTypeInfo<string>)base.Options.GetTypeInfo(typeof(string)));

	/// <summary>
	/// The default <see cref="T:System.Text.Json.Serialization.JsonSerializerContext" /> associated with a default <see cref="T:System.Text.Json.JsonSerializerOptions" /> instance.
	/// </summary>
	public static SerializableDynamicVarDictionarySerializerContext Default { get; } = new SerializableDynamicVarDictionarySerializerContext(new JsonSerializerOptions(s_defaultOptions));

	/// <summary>
	/// The source-generated options associated with this context.
	/// </summary>
	protected override JsonSerializerOptions? GeneratedSerializerOptions { get; } = s_defaultOptions;

	private JsonTypeInfo<bool> Create_Boolean(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<bool> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<bool>(options, JsonMetadataServices.BooleanConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<decimal> Create_Decimal(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<decimal> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<decimal>(options, JsonMetadataServices.DecimalConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<DynamicVarType> Create_DynamicVarType(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<DynamicVarType> jsonTypeInfo))
		{
			JsonConverter converter = ExpandConverter(typeof(DynamicVarType), new JsonStringEnumConverter<DynamicVarType>(), options);
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<DynamicVarType>(options, converter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private JsonTypeInfo<SerializableDynamicVar> Create_SerializableDynamicVar(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<SerializableDynamicVar> jsonTypeInfo))
		{
			JsonObjectInfoValues<SerializableDynamicVar> objectInfo = new JsonObjectInfoValues<SerializableDynamicVar>
			{
				ObjectCreator = () => default(SerializableDynamicVar),
				ObjectWithParameterizedConstructorCreator = null,
				PropertyMetadataInitializer = (JsonSerializerContext _) => SerializableDynamicVarPropInit(options),
				ConstructorParameterMetadataInitializer = null,
				ConstructorAttributeProviderFactory = () => typeof(SerializableDynamicVar).GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Array.Empty<Type>(), null),
				SerializeHandler = SerializableDynamicVarSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateObjectInfo(options, objectInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private static JsonPropertyInfo[] SerializableDynamicVarPropInit(JsonSerializerOptions options)
	{
		JsonPropertyInfo[] array = new JsonPropertyInfo[4];
		JsonPropertyInfoValues<DynamicVarType> propertyInfo = new JsonPropertyInfoValues<DynamicVarType>
		{
			IsProperty = false,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SerializableDynamicVar),
			Converter = null,
			Getter = (object obj) => ((SerializableDynamicVar)obj).type,
			Setter = delegate(object obj, DynamicVarType value)
			{
				Unsafe.Unbox<SerializableDynamicVar>(obj).type = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "type",
			JsonPropertyName = "type",
			AttributeProviderFactory = () => typeof(SerializableDynamicVar).GetField("type", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
		};
		array[0] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo);
		JsonPropertyInfoValues<decimal> propertyInfo2 = new JsonPropertyInfoValues<decimal>
		{
			IsProperty = false,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SerializableDynamicVar),
			Converter = null,
			Getter = (object obj) => ((SerializableDynamicVar)obj).decimalValue,
			Setter = delegate(object obj, decimal value)
			{
				Unsafe.Unbox<SerializableDynamicVar>(obj).decimalValue = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "decimalValue",
			JsonPropertyName = "decimal_value",
			AttributeProviderFactory = () => typeof(SerializableDynamicVar).GetField("decimalValue", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
		};
		array[1] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo2);
		JsonPropertyInfoValues<bool> propertyInfo3 = new JsonPropertyInfoValues<bool>
		{
			IsProperty = false,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SerializableDynamicVar),
			Converter = null,
			Getter = (object obj) => ((SerializableDynamicVar)obj).boolValue,
			Setter = delegate(object obj, bool value)
			{
				Unsafe.Unbox<SerializableDynamicVar>(obj).boolValue = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "boolValue",
			JsonPropertyName = "bool_value",
			AttributeProviderFactory = () => typeof(SerializableDynamicVar).GetField("boolValue", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
		};
		array[2] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo3);
		JsonPropertyInfoValues<string> propertyInfo4 = new JsonPropertyInfoValues<string>
		{
			IsProperty = false,
			IsPublic = true,
			IsVirtual = false,
			DeclaringType = typeof(SerializableDynamicVar),
			Converter = null,
			Getter = (object obj) => ((SerializableDynamicVar)obj).stringValue,
			Setter = delegate(object obj, string? value)
			{
				Unsafe.Unbox<SerializableDynamicVar>(obj).stringValue = value;
			},
			IgnoreCondition = null,
			HasJsonInclude = false,
			IsExtensionData = false,
			NumberHandling = null,
			PropertyName = "stringValue",
			JsonPropertyName = "string_value",
			AttributeProviderFactory = () => typeof(SerializableDynamicVar).GetField("stringValue", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
		};
		array[3] = JsonMetadataServices.CreatePropertyInfo(options, propertyInfo4);
		return array;
	}

	private void SerializableDynamicVarSerializeHandler(Utf8JsonWriter writer, SerializableDynamicVar value)
	{
		writer.WriteStartObject();
		writer.WritePropertyName(PropName_type);
		JsonSerializer.Serialize(writer, value.type, DynamicVarType);
		writer.WriteNumber(PropName_decimal_value, value.decimalValue);
		writer.WriteBoolean(PropName_bool_value, value.boolValue);
		writer.WriteString(PropName_string_value, value.stringValue);
		writer.WriteEndObject();
	}

	private JsonTypeInfo<Dictionary<string, SerializableDynamicVar>> Create_DictionaryStringSerializableDynamicVar(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<Dictionary<string, SerializableDynamicVar>> jsonTypeInfo))
		{
			JsonCollectionInfoValues<Dictionary<string, SerializableDynamicVar>> collectionInfo = new JsonCollectionInfoValues<Dictionary<string, SerializableDynamicVar>>
			{
				ObjectCreator = () => new Dictionary<string, SerializableDynamicVar>(),
				SerializeHandler = DictionaryStringSerializableDynamicVarSerializeHandler
			};
			jsonTypeInfo = JsonMetadataServices.CreateDictionaryInfo<Dictionary<string, SerializableDynamicVar>, string, SerializableDynamicVar>(options, collectionInfo);
			jsonTypeInfo.NumberHandling = null;
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	private void DictionaryStringSerializableDynamicVarSerializeHandler(Utf8JsonWriter writer, Dictionary<string, SerializableDynamicVar>? value)
	{
		if (value == null)
		{
			writer.WriteNullValue();
			return;
		}
		writer.WriteStartObject();
		foreach (KeyValuePair<string, SerializableDynamicVar> item in value)
		{
			writer.WritePropertyName(item.Key);
			SerializableDynamicVarSerializeHandler(writer, item.Value);
		}
		writer.WriteEndObject();
	}

	private JsonTypeInfo<string> Create_String(JsonSerializerOptions options)
	{
		if (!TryGetTypeInfoForRuntimeCustomConverter(options, out JsonTypeInfo<string> jsonTypeInfo))
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<string>(options, JsonMetadataServices.StringConverter);
		}
		jsonTypeInfo.OriginatingResolver = this;
		return jsonTypeInfo;
	}

	/// <inheritdoc />
	public SerializableDynamicVarDictionarySerializerContext()
		: base(null)
	{
	}

	/// <inheritdoc />
	public SerializableDynamicVarDictionarySerializerContext(JsonSerializerOptions options)
		: base(options)
	{
	}

	private static bool TryGetTypeInfoForRuntimeCustomConverter<TJsonMetadataType>(JsonSerializerOptions options, out JsonTypeInfo<TJsonMetadataType> jsonTypeInfo)
	{
		JsonConverter runtimeConverterForType = GetRuntimeConverterForType(typeof(TJsonMetadataType), options);
		if (runtimeConverterForType != null)
		{
			jsonTypeInfo = JsonMetadataServices.CreateValueInfo<TJsonMetadataType>(options, runtimeConverterForType);
			return true;
		}
		jsonTypeInfo = null;
		return false;
	}

	private static JsonConverter? GetRuntimeConverterForType(Type type, JsonSerializerOptions options)
	{
		for (int i = 0; i < options.Converters.Count; i++)
		{
			JsonConverter jsonConverter = options.Converters[i];
			if (jsonConverter != null && jsonConverter.CanConvert(type))
			{
				return ExpandConverter(type, jsonConverter, options, validateCanConvert: false);
			}
		}
		return null;
	}

	private static JsonConverter ExpandConverter(Type type, JsonConverter converter, JsonSerializerOptions options, bool validateCanConvert = true)
	{
		if (validateCanConvert && !converter.CanConvert(type))
		{
			throw new InvalidOperationException($"The converter '{converter.GetType()}' is not compatible with the type '{type}'.");
		}
		if (converter is JsonConverterFactory jsonConverterFactory)
		{
			converter = jsonConverterFactory.CreateConverter(type, options);
			if (converter == null || converter is JsonConverterFactory)
			{
				throw new InvalidOperationException($"The converter '{jsonConverterFactory.GetType()}' cannot return null or a JsonConverterFactory instance.");
			}
		}
		return converter;
	}

	/// <inheritdoc />
	public override JsonTypeInfo? GetTypeInfo(Type type)
	{
		base.Options.TryGetTypeInfo(type, out JsonTypeInfo typeInfo);
		return typeInfo;
	}

	JsonTypeInfo? IJsonTypeInfoResolver.GetTypeInfo(Type type, JsonSerializerOptions options)
	{
		if (type == typeof(bool))
		{
			return Create_Boolean(options);
		}
		if (type == typeof(decimal))
		{
			return Create_Decimal(options);
		}
		if (type == typeof(DynamicVarType))
		{
			return Create_DynamicVarType(options);
		}
		if (type == typeof(SerializableDynamicVar))
		{
			return Create_SerializableDynamicVar(options);
		}
		if (type == typeof(Dictionary<string, SerializableDynamicVar>))
		{
			return Create_DictionaryStringSerializableDynamicVar(options);
		}
		if (type == typeof(string))
		{
			return Create_String(options);
		}
		return null;
	}
}
