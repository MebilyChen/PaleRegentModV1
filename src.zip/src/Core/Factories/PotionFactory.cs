using System.Collections.Generic;
using System.Linq;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Entities.Potions;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.PotionPools;
using MegaCrit.Sts2.Core.Random;

namespace MegaCrit.Sts2.Core.Factories;

public static class PotionFactory
{
	private const float _rareChance = 0.1f;

	private const float _rareThreshold = 0.1f;

	private const float _uncommonChance = 0.25f;

	private const float _uncommonThreshold = 0.35f;

	/// <summary>
	/// Create a random potion while out of combat.
	/// This can get any potion from the valid potion pools, including potions that can do restricted things like heal
	/// the player.
	/// </summary>
	/// <param name="player">Player to create a potion for.</param>
	/// <param name="rng">RNG to use to determine what potion to create.</param>
	/// <param name="blacklist">Canonical potions that should be blocked from being generated.</param>
	/// <returns>Newly-created potion.</returns>
	public static PotionModel CreateRandomPotionOutOfCombat(Player player, Rng rng, IEnumerable<PotionModel>? blacklist = null)
	{
		return CreateRandomPotionsOutOfCombat(player, 1, rng, blacklist).First();
	}

	/// <summary>
	/// Create random potions while out of combat.
	/// This can get any potion from the valid potion pools, including potions that can do restricted things like heal
	/// the player.
	/// </summary>
	/// <param name="player">Player to create a potion for.</param>
	/// <param name="count">How many potions you want to generate.</param>
	/// <param name="rng">RNG to use to determine what potion to create.</param>
	/// <param name="blacklist">Canonical potions that should be blocked from being generated.</param>
	/// <returns>Newly-created potions.</returns>
	public static IEnumerable<PotionModel> CreateRandomPotionsOutOfCombat(Player player, int count, Rng rng, IEnumerable<PotionModel>? blacklist = null)
	{
		IEnumerable<PotionModel> enumerable = GetPotionOptions(player);
		if (blacklist != null)
		{
			enumerable = enumerable.Except(blacklist);
		}
		return CreateRandomPotions(enumerable, count, rng);
	}

	/// <summary>
	/// Create a random potion while in combat.
	/// This can get any potion from the valid potion pools, except potions that cannot be generated in combat (like
	/// healing potions).
	/// </summary>
	/// <param name="player">Player to create a potion for.</param>
	/// <param name="rng">RNG to use to determine what potion to create.</param>
	/// <param name="blacklist">Canonical potions that should be blocked from being generated.</param>
	/// <returns>Newly-created potion.</returns>
	public static PotionModel CreateRandomPotionInCombat(Player player, Rng rng, IEnumerable<PotionModel>? blacklist = null)
	{
		IEnumerable<PotionModel> enumerable = from p in GetPotionOptions(player)
			where p.CanBeGeneratedInCombat
			select p;
		if (blacklist != null)
		{
			enumerable = enumerable.Except(blacklist);
		}
		return CreateRandomPotions(enumerable, 1, rng).First();
	}

	private static IEnumerable<PotionModel> CreateRandomPotions(IEnumerable<PotionModel> options, int count, Rng rng)
	{
		List<PotionModel> list = options.ToList();
		List<PotionModel> list2 = new List<PotionModel>();
		for (int i = 0; i < count; i++)
		{
			float num = rng.NextFloat();
			PotionRarity potionRarity = ((num <= 0.1f) ? PotionRarity.Rare : ((!(num <= 0.35f)) ? PotionRarity.Common : PotionRarity.Uncommon));
			PotionRarity rarity = potionRarity;
			PotionModel item = rng.NextItem(list.Where((PotionModel potion) => potion.Rarity == rarity));
			list2.Add(item);
			list.Remove(item);
		}
		return list2;
	}

	public static IEnumerable<PotionModel> GetPotionOptions(Player player)
	{
		return player.Character.PotionPool.GetUnlockedPotions(player.UnlockState).Concat(ModelDb.PotionPool<SharedPotionPool>().GetUnlockedPotions(player.UnlockState));
	}
}
